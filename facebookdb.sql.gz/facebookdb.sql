-- MySQL dump 10.13  Distrib 5.7.20, for Linux (x86_64)
--
-- Host: localhost    Database: facebookdb
-- ------------------------------------------------------
-- Server version	5.7.20-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `chat`
--

DROP TABLE IF EXISTS `chat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chat` (
  `chat_id` int(11) NOT NULL AUTO_INCREMENT,
  `to_id` int(11) NOT NULL,
  `from_id` int(11) NOT NULL,
  `flag` varchar(1) NOT NULL,
  `text` varchar(300) NOT NULL,
  PRIMARY KEY (`chat_id`),
  KEY `to_id` (`to_id`),
  KEY `from_id` (`from_id`),
  CONSTRAINT `chat_ibfk_1` FOREIGN KEY (`to_id`) REFERENCES `userprofile` (`id`),
  CONSTRAINT `chat_ibfk_2` FOREIGN KEY (`from_id`) REFERENCES `userprofile` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat`
--

LOCK TABLES `chat` WRITE;
/*!40000 ALTER TABLE `chat` DISABLE KEYS */;
INSERT INTO `chat` VALUES (1,14,7,'1','atul'),(2,12,7,'1','hello Sir'),(3,12,7,'1','How are you'),(4,12,7,'1','hi '),(5,12,7,'1','hello'),(6,7,12,'1','hehehehehehehe'),(7,7,12,'1','heheheheh'),(8,7,12,'1','asaaaaaaaaaaaaaaa'),(9,7,12,'1','aaa'),(10,7,12,'1','helo'),(11,7,12,'1','hello'),(12,7,12,'1','how are you. Are you opting for design patterns'),(13,12,7,'1','i m fine sire thank you'),(14,7,12,'1','as');
/*!40000 ALTER TABLE `chat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_comments`
--

DROP TABLE IF EXISTS `event_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_comments` (
  `comment_id` int(11) NOT NULL AUTO_INCREMENT,
  `commenttext` varchar(300) NOT NULL,
  `user_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `creation_time` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`comment_id`),
  KEY `user_id` (`user_id`),
  KEY `post_id` (`post_id`),
  CONSTRAINT `event_comments_ibfk_2` FOREIGN KEY (`post_id`) REFERENCES `group_postinfo` (`post_id`) ON DELETE CASCADE,
  CONSTRAINT `event_comments_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `userprofile` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_comments`
--

LOCK TABLES `event_comments` WRITE;
/*!40000 ALTER TABLE `event_comments` DISABLE KEYS */;
INSERT INTO `event_comments` VALUES (1,'Nice',7,2,'1492728333117');
/*!40000 ALTER TABLE `event_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_info`
--

DROP TABLE IF EXISTS `event_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_info` (
  `event_id` int(11) NOT NULL AUTO_INCREMENT,
  `event_name` varchar(100) NOT NULL,
  `evet_detail` varchar(1000) DEFAULT NULL,
  `admin_id` int(11) NOT NULL,
  `piclocation` varchar(100) DEFAULT 'a.jpg',
  `event_type` int(11) DEFAULT '0',
  `start_date` varchar(100) DEFAULT NULL,
  `end_date` varchar(100) DEFAULT NULL,
  `location` varchar(100) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `summary` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`event_id`),
  KEY `admin_id` (`admin_id`),
  CONSTRAINT `event_info_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES `userprofile` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_info`
--

LOCK TABLES `event_info` WRITE;
/*!40000 ALTER TABLE `event_info` DISABLE KEYS */;
INSERT INTO `event_info` VALUES (7,'OOAD',NULL,7,'a.jpg',0,'1495377776445','','IIIT-B','NEW',NULL),(8,'NEW',NULL,7,'a.jpg',0,'-23886983827545','','NWWWW','NICE',NULL),(9,'aaa',NULL,7,'a.jpg',0,'-23886983869340','','aaa','121212',NULL),(10,'xxx',NULL,7,'events/10/1492716728483profile.jpg',0,'1495387808113','','RED','anubhav',NULL),(11,'anubhav',NULL,7,'a.jpg',0,'1515739336897','1547275336897','IIIT','rest',NULL),(12,'BATMAN',NULL,7,'events/12/1492718758848profile.jpg',0,'1495377058554','','GOTHAM','BATMAN','HHHHHHHHHHHHHHHHHHHHH'),(13,'aaaa',NULL,12,'a.jpg',0,'1492720214274','1492733354274','aaa','asasas','gagaga'),(14,'aaa',NULL,7,'a.jpg',0,'-23889662272952','-23889660592952','aaaa','',NULL);
/*!40000 ALTER TABLE `event_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_likes`
--

DROP TABLE IF EXISTS `event_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_likes` (
  `like_id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`like_id`),
  UNIQUE KEY `post_id` (`post_id`,`user_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `event_likes_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `event_postinfo` (`post_id`) ON DELETE CASCADE,
  CONSTRAINT `event_likes_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `userprofile` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_likes`
--

LOCK TABLES `event_likes` WRITE;
/*!40000 ALTER TABLE `event_likes` DISABLE KEYS */;
INSERT INTO `event_likes` VALUES (3,1,7),(4,2,7),(5,2,12);
/*!40000 ALTER TABLE `event_likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_participants`
--

DROP TABLE IF EXISTS `event_participants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_participants` (
  `event_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `event_type` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT '0',
  `flag` int(2) DEFAULT '0',
  KEY `member_id` (`member_id`),
  KEY `event_id` (`event_id`),
  CONSTRAINT `event_participants_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `userprofile` (`id`) ON DELETE CASCADE,
  CONSTRAINT `event_participants_ibfk_2` FOREIGN KEY (`event_id`) REFERENCES `event_info` (`event_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_participants`
--

LOCK TABLES `event_participants` WRITE;
/*!40000 ALTER TABLE `event_participants` DISABLE KEYS */;
INSERT INTO `event_participants` VALUES (7,12,NULL,1,0),(7,5,NULL,0,7),(7,7,NULL,1,0),(10,12,NULL,1,7),(10,5,NULL,0,7);
/*!40000 ALTER TABLE `event_participants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_postinfo`
--

DROP TABLE IF EXISTS `event_postinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_postinfo` (
  `post_id` int(11) NOT NULL AUTO_INCREMENT,
  `event_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `textfield` varchar(500) DEFAULT NULL,
  `piclocation` varchar(300) DEFAULT NULL,
  `creationtime` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`post_id`),
  KEY `event_id` (`event_id`),
  KEY `member_id` (`member_id`),
  CONSTRAINT `event_postinfo_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `userprofile` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_postinfo`
--

LOCK TABLES `event_postinfo` WRITE;
/*!40000 ALTER TABLE `event_postinfo` DISABLE KEYS */;
INSERT INTO `event_postinfo` VALUES (1,7,7,'ghll','events/7/1492727871931_bags_minimalism_black_cat_night_monster_25780_1920x1080.jpg','1492727871931'),(2,7,7,'TEST','events/7/1492727952746_Adventure-Time-Cartoon-Hd-Wallpapers.jpg','1492727952746');
/*!40000 ALTER TABLE `event_postinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `friendlist`
--

DROP TABLE IF EXISTS `friendlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `friendlist` (
  `id1` int(10) NOT NULL,
  `id2` int(10) NOT NULL,
  KEY `id2` (`id2`),
  KEY `id1` (`id1`),
  CONSTRAINT `friendlist_ibfk_1` FOREIGN KEY (`id2`) REFERENCES `userprofile` (`id`) ON DELETE CASCADE,
  CONSTRAINT `friendlist_ibfk_2` FOREIGN KEY (`id1`) REFERENCES `userprofile` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `friendlist`
--

LOCK TABLES `friendlist` WRITE;
/*!40000 ALTER TABLE `friendlist` DISABLE KEYS */;
INSERT INTO `friendlist` VALUES (7,3),(3,14),(7,5),(14,12),(5,12),(3,12),(7,12),(14,4),(12,4),(14,6),(12,6),(6,4),(14,8),(14,9),(5,10),(9,10),(8,11),(7,13),(12,13),(12,24),(8,23),(9,23),(8,22),(23,22),(4,21),(14,19),(12,19),(4,19),(7,17),(5,17),(12,17),(11,22),(15,12),(12,22),(12,23),(21,12),(12,8),(12,9),(14,7);
/*!40000 ALTER TABLE `friendlist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_comments`
--

DROP TABLE IF EXISTS `group_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_comments` (
  `comment_id` int(11) NOT NULL AUTO_INCREMENT,
  `commenttext` varchar(300) NOT NULL,
  `user_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `creation_time` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`comment_id`),
  KEY `user_id` (`user_id`),
  KEY `post_id` (`post_id`),
  CONSTRAINT `group_comments_ibfk_2` FOREIGN KEY (`post_id`) REFERENCES `group_postinfo` (`post_id`) ON DELETE CASCADE,
  CONSTRAINT `group_comments_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `userprofile` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_comments`
--

LOCK TABLES `group_comments` WRITE;
/*!40000 ALTER TABLE `group_comments` DISABLE KEYS */;
INSERT INTO `group_comments` VALUES (1,'thanks arpit',15,1,'1492615217190'),(2,'Why?',23,2,'1492640478667');
/*!40000 ALTER TABLE `group_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_info`
--

DROP TABLE IF EXISTS `group_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_info` (
  `group_id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(100) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `piclocation` varchar(100) DEFAULT 'a.jpg',
  `privacy` int(11) DEFAULT '0',
  PRIMARY KEY (`group_id`),
  KEY `admin_id` (`admin_id`),
  CONSTRAINT `group_info_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES `userprofile` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_info`
--

LOCK TABLES `group_info` WRITE;
/*!40000 ALTER TABLE `group_info` DISABLE KEYS */;
INSERT INTO `group_info` VALUES (1,'WING A',23,'groups/1/1492615252787profile.jpg',0),(2,'MITRA MANDLI',22,'a.jpg',1),(3,'OOAD',3,'a.jpg',1),(4,'21 April',12,'a.jpg',0),(5,'aaaaaa',3,'a.jpg',0);
/*!40000 ALTER TABLE `group_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_likes`
--

DROP TABLE IF EXISTS `group_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_likes` (
  `like_id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`like_id`),
  UNIQUE KEY `post_id` (`post_id`,`user_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `group_likes_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `group_postinfo` (`post_id`) ON DELETE CASCADE,
  CONSTRAINT `group_likes_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `userprofile` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_likes`
--

LOCK TABLES `group_likes` WRITE;
/*!40000 ALTER TABLE `group_likes` DISABLE KEYS */;
INSERT INTO `group_likes` VALUES (1,1,15),(2,2,23),(3,5,12),(4,7,12);
/*!40000 ALTER TABLE `group_likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_members`
--

DROP TABLE IF EXISTS `group_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_members` (
  `group_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  KEY `group_id` (`group_id`),
  KEY `member_id` (`member_id`),
  CONSTRAINT `group_members_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `userprofile` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_members`
--

LOCK TABLES `group_members` WRITE;
/*!40000 ALTER TABLE `group_members` DISABLE KEYS */;
INSERT INTO `group_members` VALUES (1,23),(1,8),(1,9),(2,22),(1,19),(1,15),(3,3),(3,12),(3,7),(2,23),(2,12),(2,7),(3,14),(4,12),(4,4),(4,19),(4,3),(5,3),(5,14),(5,7);
/*!40000 ALTER TABLE `group_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_postinfo`
--

DROP TABLE IF EXISTS `group_postinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_postinfo` (
  `post_id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `textfield` varchar(500) DEFAULT NULL,
  `piclocation` varchar(300) DEFAULT NULL,
  `creationtime` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`post_id`),
  KEY `group_id` (`group_id`),
  KEY `member_id` (`member_id`),
  CONSTRAINT `group_postinfo_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `userprofile` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_postinfo`
--

LOCK TABLES `group_postinfo` WRITE;
/*!40000 ALTER TABLE `group_postinfo` DISABLE KEYS */;
INSERT INTO `group_postinfo` VALUES (1,1,23,'WELCOME TO GROUP','groups/1/1492614749634_calvin-and-hobbes-minimalism-cartoon-1080P-wallpaper.jpg','1492614749634'),(2,2,22,'Let\'s go to Nepal','groups/2/1492614864640_www.dmzwarez.info_Natures_ 0005.jpg','1492614864640'),(3,1,15,'please send me friend requests\r\n',NULL,'1492615232415'),(4,2,23,'I am Batman','groups/2/1492640491590_batman_minimalism_comics_69253_1920x1080.jpg','1492640491590'),(5,3,12,'ALL THE BEST FOR TEST','groups/3/1492730306823_flat_tarmac_wallpaper_green_by_microfreaks-d8c6gtb.png','1492730306823'),(6,4,12,'',NULL,'1493975044602'),(7,4,12,'nice','groups/4/1493975063279_avi.jpg','1493975063279');
/*!40000 ALTER TABLE `group_postinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pending_request`
--

DROP TABLE IF EXISTS `pending_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pending_request` (
  `req_id` int(11) NOT NULL AUTO_INCREMENT,
  `from_id` int(11) NOT NULL,
  `to_id` int(11) NOT NULL,
  `onhold` int(1) DEFAULT '0',
  PRIMARY KEY (`req_id`),
  UNIQUE KEY `from_id` (`from_id`,`to_id`),
  UNIQUE KEY `to_id` (`to_id`,`from_id`),
  CONSTRAINT `pending_request_ibfk_1` FOREIGN KEY (`to_id`) REFERENCES `userprofile` (`id`) ON DELETE CASCADE,
  CONSTRAINT `pending_request_ibfk_2` FOREIGN KEY (`from_id`) REFERENCES `userprofile` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pending_request`
--

LOCK TABLES `pending_request` WRITE;
/*!40000 ALTER TABLE `pending_request` DISABLE KEYS */;
INSERT INTO `pending_request` VALUES (32,9,8,0),(35,24,3,0),(36,23,3,0),(40,15,3,0),(42,14,15,0),(43,7,10,0),(44,7,8,0),(52,15,24,0);
/*!40000 ALTER TABLE `pending_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post_comments`
--

DROP TABLE IF EXISTS `post_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `post_comments` (
  `comment_id` int(11) NOT NULL AUTO_INCREMENT,
  `commenttext` varchar(300) NOT NULL,
  `user_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `creation_time` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`comment_id`),
  KEY `user_id` (`user_id`),
  KEY `post_id` (`post_id`),
  CONSTRAINT `post_comments_ibfk_2` FOREIGN KEY (`post_id`) REFERENCES `postinfo` (`postid`) ON DELETE CASCADE,
  CONSTRAINT `post_comments_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `userprofile` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_comments`
--

LOCK TABLES `post_comments` WRITE;
/*!40000 ALTER TABLE `post_comments` DISABLE KEYS */;
INSERT INTO `post_comments` VALUES (1,'very nice caves',19,1,'1492615050412'),(2,'where are you nowdays',7,1,'1492615478545'),(3,'thank you sir',5,10,'1492615506015'),(4,'nice snap ashish',5,8,'1492615515517'),(5,'thank you sir',3,10,'1492615564253'),(6,'please make is easy sir',14,10,'1492615671487'),(7,'oh oh',14,6,'1492615679092'),(8,'Yes Sir please',7,10,'1492615826854'),(9,'Nice pet',7,4,'1492615835857'),(10,'and alone',7,3,'1492615842080'),(11,'Yours is on Saturday',7,11,'1492616083560');
/*!40000 ALTER TABLE `post_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post_likes`
--

DROP TABLE IF EXISTS `post_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `post_likes` (
  `like_id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`like_id`),
  UNIQUE KEY `post_id` (`post_id`,`user_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `post_likes_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `postinfo` (`postid`) ON DELETE CASCADE,
  CONSTRAINT `post_likes_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `userprofile` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_likes`
--

LOCK TABLES `post_likes` WRITE;
/*!40000 ALTER TABLE `post_likes` DISABLE KEYS */;
INSERT INTO `post_likes` VALUES (1,1,3),(11,1,7),(4,1,19),(2,2,11),(16,3,7),(3,5,21),(5,6,19),(10,7,7),(7,7,17),(13,8,5),(9,8,7),(6,8,17),(14,10,3),(12,10,5),(8,10,7),(15,10,14),(17,13,7),(18,14,12);
/*!40000 ALTER TABLE `post_likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `postinfo`
--

DROP TABLE IF EXISTS `postinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `postinfo` (
  `postid` int(11) NOT NULL AUTO_INCREMENT,
  `id` int(11) NOT NULL,
  `textfeild` varchar(300) DEFAULT NULL,
  `piclocation` varchar(200) DEFAULT NULL,
  `creation_time` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`postid`),
  KEY `id` (`id`),
  CONSTRAINT `postinfo_ibfk_1` FOREIGN KEY (`id`) REFERENCES `userprofile` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `postinfo`
--

LOCK TABLES `postinfo` WRITE;
/*!40000 ALTER TABLE `postinfo` DISABLE KEYS */;
INSERT INTO `postinfo` VALUES (1,14,'in the nature','users/14/1492611468472_www.dmzwarez.info_Natures_ 0002.jpg','1492611468472'),(2,11,'NIGHT OUT','users/11/1492613885416_mountain_climber_flat_wallpapers_4k_minimalist_by_designuchiha-da4joie.jpg','1492613885416'),(3,22,'hello friends i\'m new here',NULL,'1492614810131'),(4,22,'me with my pet','users/22/1492614820458_Adventure-Time-Cartoon-Hd-Wallpapers.jpg','1492614820458'),(5,21,'In africa','users/21/1492614905221_www.dmzwarez.info_Natures_ 0017.jpg','1492614905221'),(6,19,'NICE FEELING WHEN ON FACEBOOK',NULL,'1492615028406'),(7,17,'Hello friends let\'s go to goa\r\n\r\n',NULL,'1492615105862'),(8,17,'My photography','users/17/1492615116976_www.dmzwarez.info_Natures_ 0045.jpg','1492615116976'),(9,15,'this is my life','users/15/1492615186989_www.dmzwarez.info_Natures_ 0044.jpg','1492615186989'),(10,12,'all the best for ooad test ','users/12/1492615417503_www.dmzwarez.info_Natures_ 0008.jpg','1492615417503'),(11,5,'When is OOAD test',NULL,'1492615643545'),(12,7,'going for movies','users/7/1492616274164_Night-in-flat-town-1600-1200.jpg','1492616274164'),(13,7,'Having dinner in mess guys. Hope i come alive.',NULL,'1492616321235'),(14,21,'','users/21/1492641418792_calvin_and_hobbs_minimalism_tiger_25598_1920x1080.jpg','1492641418792'),(15,7,'Happy birthday','users/7/1502857949733_Selection_002.png','1502857949733'),(16,12,'hello',NULL,'1510218767228');
/*!40000 ALTER TABLE `postinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sports`
--

DROP TABLE IF EXISTS `sports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sports` (
  `user_id` int(11) NOT NULL,
  `sports` varchar(20) DEFAULT 'None',
  PRIMARY KEY (`user_id`),
  CONSTRAINT `sports_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `userprofile` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sports`
--

LOCK TABLES `sports` WRITE;
/*!40000 ALTER TABLE `sports` DISABLE KEYS */;
INSERT INTO `sports` VALUES (2,'Cricket'),(3,'Chess'),(4,'Football'),(5,'Wresling'),(6,'Cricket'),(7,'Chess'),(8,'Football'),(9,'Wresling'),(10,'Cricket'),(11,'Chess'),(12,'Wresling'),(13,'Wresling'),(14,'Cricket'),(15,'Chess'),(16,'Football'),(17,'Wresling'),(19,'Hockey'),(20,'Hockey'),(21,'Hockey'),(22,'Cricket'),(23,'Football'),(24,'None');
/*!40000 ALTER TABLE `sports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suggestion`
--

DROP TABLE IF EXISTS `suggestion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `suggestion` (
  `sug_id` int(11) NOT NULL AUTO_INCREMENT,
  `from_id` int(11) NOT NULL,
  `to_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`sug_id`),
  UNIQUE KEY `to_id` (`to_id`,`user_id`),
  KEY `from_id` (`from_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `suggestion_ibfk_1` FOREIGN KEY (`from_id`) REFERENCES `userprofile` (`id`) ON DELETE CASCADE,
  CONSTRAINT `suggestion_ibfk_2` FOREIGN KEY (`to_id`) REFERENCES `userprofile` (`id`) ON DELETE CASCADE,
  CONSTRAINT `suggestion_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `userprofile` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suggestion`
--

LOCK TABLES `suggestion` WRITE;
/*!40000 ALTER TABLE `suggestion` DISABLE KEYS */;
INSERT INTO `suggestion` VALUES (1,10,5,9),(35,12,7,15);
/*!40000 ALTER TABLE `suggestion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userotherinfo`
--

DROP TABLE IF EXISTS `userotherinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userotherinfo` (
  `hometown` varchar(30) DEFAULT NULL,
  `country` varchar(30) DEFAULT NULL,
  `work` varchar(40) DEFAULT NULL,
  `livesin` varchar(30) DEFAULT NULL,
  `college` varchar(30) DEFAULT NULL,
  `id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `userotherinfo_ibfk_1` FOREIGN KEY (`id`) REFERENCES `userprofile` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userotherinfo`
--

LOCK TABLES `userotherinfo` WRITE;
/*!40000 ALTER TABLE `userotherinfo` DISABLE KEYS */;
INSERT INTO `userotherinfo` VALUES (NULL,NULL,NULL,NULL,NULL,2),('Bangalore','India','amazon',NULL,'IIIT-B',3),(NULL,NULL,NULL,NULL,NULL,4),(NULL,NULL,NULL,NULL,NULL,5),(NULL,NULL,NULL,NULL,NULL,6),('Bangalore','India','Student',NULL,'IIIT-B',7),(NULL,NULL,NULL,NULL,NULL,8),(NULL,NULL,NULL,NULL,NULL,9),(NULL,NULL,NULL,NULL,NULL,10),(NULL,NULL,NULL,NULL,NULL,11),('Bengaluru','India','IIIT-B',NULL,'IIT Bombay',12),(NULL,NULL,NULL,NULL,NULL,13),('pune','Sri Lanka','amazon',NULL,'IIIT-B',14),(NULL,NULL,NULL,NULL,NULL,15),(NULL,NULL,NULL,NULL,NULL,16),(NULL,NULL,NULL,NULL,NULL,17),(NULL,NULL,NULL,NULL,NULL,19),(NULL,NULL,NULL,NULL,NULL,20),('Indore','India','amazon',NULL,'IIIT-B',21),(NULL,NULL,NULL,NULL,NULL,22),('','','Student',NULL,'IIIT-B',23),(NULL,NULL,NULL,NULL,NULL,24);
/*!40000 ALTER TABLE `userotherinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userprofile`
--

DROP TABLE IF EXISTS `userprofile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userprofile` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobileno` varchar(10) DEFAULT NULL,
  `password` varchar(100) NOT NULL,
  `dateofbirth` varchar(50) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `picturepath` varchar(150) DEFAULT 'a.jpg',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userprofile`
--

LOCK TABLES `userprofile` WRITE;
/*!40000 ALTER TABLE `userprofile` DISABLE KEYS */;
INSERT INTO `userprofile` VALUES (2,'Mehul','Singh','mehulsingh57@gmail.com','9761200316','1234','4 September 1993','male','a.jpg'),(3,'Mudit','Saini','muditmks@gmail.com','7740816621','1234','4 September 1993','male','users/3/1492612275424profile.jpg'),(4,'Neha','Jain','03nehajain@gmail.com','8827842540','1234','4 September 1993','female','a.jpg'),(5,'Eshita','Kukreja','eshita.isar@gmail.com','9909876543','1234','4 September 1993','female','users/5/1492615537439profile.jpg'),(6,'Nelluri','Naveen','naveen.nelluri72@gmail.com','8095330130','1234','4 September 1993','male','a.jpg'),(7,'Anubhav','gupta','anubhavgupta4993@gmail.com','8305771509','1234','04 September 1993','male','users/7/1493975187689profile.jpg'),(8,'Sujit','Saini','Sujitmks@gmail.com','7740816621','1234','4 September 1993','male','a.jpg'),(9,'Narendre','Modi','mitro@bjp.com','9111009994','1234','4 September 1993','male','a.jpg'),(10,'Rahul','Gandhi','rahulgandhi@pappu.com','777856569','1234','4 September 1993','female','a.jpg'),(11,'Chanki','Panday','chankipanday773@gmail.com','8305771454','1234','4 September 1993','female','a.jpg'),(12,'dinesha','KV','kvdinesha@iiitb.ac.in','9999990090','1234','4 September 1993','Male','users/12/1510218661114profile.jpg'),(13,'Neha','Dixit','2801neha@gmail.com',NULL,'1234','4 September 1993','Female','a.jpg'),(14,'Atul','Agarwal','kingatul@gmail.com','8308275738','1234','4 September 1993','Male','users/14/1492611508680profile.jpg'),(15,'aakaash','jain','akash@gmial.com',NULL,'1234','4 September 1993','Male','a.jpg'),(16,'temp','temp','temp@yahoo.in',NULL,'1234','4 September 1993','Male','a.jpg'),(17,'ashish','gupta','ashish.gupta@iiitb.org',NULL,'1234','4 September 1993','Male','a.jpg'),(19,'aman','bansal','aman.bansal@iiitb.org',NULL,'1234','4 September 1993','Male','users/19/1492614997771profile.jpg'),(20,'te','te','te@gmail.com',NULL,'1234','4 September 1993','Male','a.jpg'),(21,'jai','mataji','letsrock@jmd.com','','1234','4 September 1993','Female','users/21/1492641399031profile.jpg'),(22,'Anupam','Awasthi','anupam.awasthi@iiitb.org',NULL,'1234','12 March 1992','Male','a.jpg'),(23,'arpit','waghmare','arpit.waghmare@iiitb.org','','1234','20 December 1993','Male','a.jpg'),(24,'Harshal','Garg','harshal@gmail.com',NULL,'1234','16 May 1994','Male','a.jpg');
/*!40000 ALTER TABLE `userprofile` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-03-24 11:29:07
